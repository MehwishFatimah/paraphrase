/***********************************************************************
 Moses - statistical machine translation system
 Copyright (C) 2006-2012 University of Edinburgh

 This library is free software; you can redistribute it and/or
 modify it under the terms of the GNU Lesser General Public
 License as published by the Free Software Foundation; either
 version 2.1 of the License, or (at your option) any later version.

 This library is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 Lesser General Public License for more details.

 You should have received a copy of the GNU Lesser General Public
 License along with this library; if not, write to the Free Software
 Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 ***********************************************************************/

#pragma once

#include <utility>

namespace Moses
{

/** @todo what is this?
 */
struct IntermediateVarSpanNode
{
 public:
  typedef std::pair<int, int> Range;

  IntermediateVarSpanNode()
    : m_start(Range(-1, -1))
    , m_end(Range(-1, -1))
    , m_numSplitPoints(0) {}

  IntermediateVarSpanNode(const Range &start, const Range &end)
    : m_start(start)
    , m_end(end)
    , m_numSplitPoints(0) {}

  bool isOpen() { return m_end.second == -1; }
  bool isClosed() { return !isOpen(); }

  Range m_start;
  Range m_end;
  int m_numSplitPoints;
};

}
