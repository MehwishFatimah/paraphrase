#pragma once

#include <string>

void create_xml(const std::string &inPath);
